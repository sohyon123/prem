import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../constants/Utiles.dart';
import '../constants/constants.dart';

extension DateOnlyCompare on DateTime {
  bool isSameDate(DateTime other) {
    return year == other.year && month == other.month && day == other.day;
  }
}

class StudentLecturePage extends StatefulWidget {
  StudentLecturePage({
    super.key,
    required,
  });

  @override
  State<StudentLecturePage> createState() => _StudentLecturePageState();
}

class _StudentLecturePageState extends State<StudentLecturePage> {
  bool isDateSame(DateTime eventDate) {
    if (_focusedDay.year == eventDate.year &&
        _focusedDay.month == eventDate.month &&
        _focusedDay.day == eventDate.day) {
      return true;
    } else {
      return false;
    }
  }

  List<DateTime> events = [];
  late final ValueNotifier<List<Event>> _selectedEvents;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOff; // Can be toggled on/off by longpressing a date
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  bool check = false;
  @override
  void initState() {
    super.initState();

    _selectedDay = _focusedDay;
    _selectedEvents = ValueNotifier(_getEventsForDay(_selectedDay!));
    //events
    Future.delayed(Duration(seconds: 3), () async {
      setState(() {
        this.check = true;
      });
    });
    FirebaseFirestore.instance
        .collection('lectures')
        // .where("userId", isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .snapshots()
        .map((QuerySnapshot snapshot) {
      print(snapshot.size.toString() + "asdasdq22");

      for (int i = 0; i < snapshot.size; i++) {
        Timestamp t = snapshot.docs[i]['lectureDate'];
        DateTime d = t.toDate();
        print(d);

        events.add(d);

        // print(snapshot.docs[i]['createdAt'].toString()+i.toString() + "asdsadda");
      }
    }).single;
    super.initState();
  }

  @override
  void dispose() {
    _selectedEvents.dispose();
    super.dispose();
  }

  List<Event> _getEventsForDay(DateTime day) {
    // Implementation example
    return kEvents[day] ?? [];
  }

  List<Event> _getEventsForRange(DateTime start, DateTime end) {
    // Implementation example
    final days = daysInRange(start, end);

    return [
      for (final d in days) ..._getEventsForDay(d),
    ];
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    if (!isSameDay(_selectedDay, selectedDay)) {
      setState(() {
        _selectedDay = selectedDay;
        _focusedDay = focusedDay;
        _rangeStart = null; // Important to clean those
        _rangeEnd = null;
        _rangeSelectionMode = RangeSelectionMode.toggledOff;
      });

      _selectedEvents.value = _getEventsForDay(selectedDay);
    }
    print(_selectedDay);
    print(DateTime.now());

    print(_focusedDay);
  }

  void _onRangeSelected(DateTime? start, DateTime? end, DateTime focusedDay) {
    setState(() {
      _selectedDay = null;
      _focusedDay = focusedDay;
      _rangeStart = start;
      _rangeEnd = end;
      _rangeSelectionMode = RangeSelectionMode.toggledOn;
    });

    // `start` or `end` could be null
    if (start != null && end != null) {
      _selectedEvents.value = _getEventsForRange(start, end);
    } else if (start != null) {
      _selectedEvents.value = _getEventsForDay(start);
    } else if (end != null) {
      _selectedEvents.value = _getEventsForDay(end);
    }
  }

  DateTime kToday = DateTime.now();
  DateTime kFirstDay = DateTime(
      DateTime.now().year, DateTime.now().month - 3, DateTime.now().day);
  DateTime kLastDay = DateTime(
      DateTime.now().year, DateTime.now().month + 3, DateTime.now().day);
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('userDetails')
            .where("userId", isEqualTo: FirebaseAuth.instance.currentUser!.uid)
            .limit(1)
            .snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          // String data = snapshot.data.toString();
          if (!snapshot.hasData) return SizedBox();
          return Scaffold(
            appBar: AppBar(
              elevation: 0,
              title: Text(
                "Student Lectures",
                // style: kBodyText.copyWith(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              centerTitle: true,
              backgroundColor: kWhite,
            ),
            backgroundColor: Colors.white,
            body: SingleChildScrollView(
              child: Column(
                children: [
                  Center(
                    child: Container(
                      width: Get.width * 0.90,
                      // height: 350,
                      color: kCyan,
                      child: TableCalendar(
                        calendarFormat: _calendarFormat,
                        firstDay: kFirstDay,
                        lastDay: kLastDay,
                        focusedDay: _focusedDay,

                        holidayPredicate: (day) {
                          //start of has code
                          var holiday = false;

                          //end of has code

                          events.forEach((element) {
                            if (isSameDay(element, day)) {
                              holiday = true;
                            }
                          });
                          return holiday == true ? true : false;
                        },

                        selectedDayPredicate: (day) =>
                            isSameDay(_selectedDay, day),
                        rangeStartDay: _rangeStart,
                        rangeEndDay: _rangeEnd,

                        rangeSelectionMode: _rangeSelectionMode,
                        //   eventLoader: events,
                        startingDayOfWeek: StartingDayOfWeek.monday,
                        daysOfWeekStyle: DaysOfWeekStyle(
                            weekdayStyle: TextStyle(
                              color: kBlack,
                            ),
                            weekendStyle: TextStyle(
                              color: kBlack,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                            )),
                        headerStyle: HeaderStyle(
                          titleTextStyle: TextStyle(
                            color: Colors.white,
                          ),
                          formatButtonVisible: true,
                          //formatButtonDecoration: BoxDecoration(),
                          formatButtonTextStyle: TextStyle(color: kWhite),
                          leftChevronIcon: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                          ),
                          // leftChevronMargin: EdgeInsets.only(left: 100.w),
                          rightChevronIcon: Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.white,
                          ),
                        ),

                        calendarStyle: CalendarStyle(
                          canMarkersOverflow: true,
                          tableBorder: TableBorder(
                            horizontalInside: BorderSide(color: Colors.grey),
                            verticalInside: BorderSide(color: Colors.grey),
                            bottom: BorderSide(color: Colors.grey),
                            left: BorderSide(color: Colors.grey),
                            right: BorderSide(color: Colors.grey),
                            top: BorderSide(color: Colors.grey),
                          ),
                          markerDecoration: BoxDecoration(
                            color: kDarkGrey,
                            shape: BoxShape.circle,
                          ),
                          outsideTextStyle: TextStyle(
                            color: Colors.white,
                          ),
                          defaultTextStyle: TextStyle(
                            color: Colors.white,
                          ),
                          weekendTextStyle: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                        onDaySelected: _onDaySelected,
                        onRangeSelected: _onRangeSelected,
                        onFormatChanged: (format) {
                          if (_calendarFormat != format) {
                            setState(() {
                              _calendarFormat = format;
                            });
                          }
                        },

                        onPageChanged: (focusedDay) {
                          setState(() {
                            _focusedDay = focusedDay;
                            print(_focusedDay);
                          });
                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('lectures')
                          //  .where("eventDate",isEqualTo: _focusedDay.d)

                          // .where("timestamp",isEqualTo: DateTime.now())

                          // .where("eventDate",isLessThanOrEqualTo: DateTime.now())
                          .orderBy('lectureDate', descending: false)
                          .snapshots(),
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        // String data = snapshot.data.toString();
                        if (!snapshot.hasData) return SizedBox();
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: snapshot.data!.docs.map((lectureDetails) {
                            //  List<String> imageUrls =List.from(userDocument['picUrl']);

                            return isDateSame(
                                    lectureDetails["lectureDate"].toDate())
                                ? Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15.0),
                                      border: Border.all(
                                        color: kDark,
                                        width: 1,
                                      ),
                                      color: kWhite,
                                      boxShadow: [
                                        BoxShadow(
                                          color: kCyan,
                                          spreadRadius: 1,
                                          blurRadius: 1,
                                          // offset: Offset(0, 0), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    margin: EdgeInsets.only(
                                        left: 30,
                                        top: MediaQuery.of(context)
                                                .viewPadding
                                                .top +
                                            17,
                                        right: 30),
                                    //  padding: EdgeInsets.only(left: 10,top: 10),
                                    // color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text("Lecture Name",
                                                style: kTextHeadingStyle(
                                                    17, kBlack)),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              lectureDetails['lectureName']
                                                  .toString()
                                                  .capitalizeFirst!,
                                              style: kTextNormalStyle(
                                                  14, kDarkGrey),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text("Lecture Place",
                                                style: kTextHeadingStyle(
                                                    17, kBlack)),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                                lectureDetails['lecturePlace']
                                                    .toString()
                                                    .capitalizeFirst!,
                                                style: kTextNormalStyle(
                                                    14, kDarkGrey)),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text("Lecture Date",
                                                    style: kTextHeadingStyle(
                                                        17, kBlack)),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                Text(
                                                    DateFormat.yMMMEd()
                                                        .format(lectureDetails[
                                                                'lectureDate']
                                                            .toDate())
                                                        .toString()!,
                                                    style: kTextNormalStyle(
                                                        14, kDarkGrey)),
                                              ],
                                            ),
                                            Spacer(),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text("Lecture Time",
                                                    style: kTextHeadingStyle(
                                                        17, kBlack)),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                Text(
                                                    lectureDetails[
                                                            'lectureTime']
                                                        .toString()
                                                        .capitalizeFirst!,
                                                    style: kTextNormalStyle(
                                                        14, kDarkGrey)),
                                              ],
                                            ),
                                            SizedBox(
                                              width: 15,
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        SizedBox(
                                          height: 15,
                                        )
                                      ],
                                    ),
                                  )
                                : SizedBox();
                            //if search is less then 3 characters
                          }).toList(),
                        );
                      }),
                  SizedBox(
                    height: 25,
                  ),
                ],
              ),
            ),
          );
        });
  }
}
