import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:evenmanagment/root.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';

import '../constants/constants.dart';
import '../profile/editProfile.dart';

//main class for admin
class AdminHomePage extends StatefulWidget {
  AdminHomePage({
    super.key,
    required,
  });

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('userDetails')
            .where("userId", isEqualTo: FirebaseAuth.instance.currentUser!.uid)
            .limit(1)
            .snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return SizedBox();
          return DefaultTabController(
              length: 2,
              child: Scaffold(
                appBar: PreferredSize(
                  preferredSize: Size.fromHeight(125), // Set this height
                  child: Container(
                    //margin: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        AppBar(
                          elevation: 0,
                          title: Text(
                            "PREM",
                            // style: kBodyText.copyWith(fontWeight: FontWeight.bold, fontSize: 25),
                          ),
                          centerTitle: true,
                          backgroundColor: kWhite,
                        ),
                        //   Divider(color: Colors.black,thickness: 2,),
                        TabBar(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          indicator: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(10), // Creates border
                              color: kCyan),

//indicatorColor: Colors.black,
                          tabs: [
                            Tab(
                              child: Text(
                                "Events",
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                            Tab(
                                child: Text(
                              "Lectures",
                              style: TextStyle(color: Colors.black),
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                drawer: !snapshot.hasData
                    ? SizedBox()
                    : Drawer(
                        backgroundColor: kCyan,
                        child: ListView(
                          padding: EdgeInsets.zero,
                          children: <Widget>[
                            DrawerHeader(
                                decoration: BoxDecoration(
                                  color: kCyan,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    // SizedBox(height: 5,),
                                    Text(
                                      "Welcome! " +
                                          snapshot.data?.docs[0]['name'],
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                    //   SizedBox(height: 5,),
                                  ],
                                )),
                            ListTile(
                              leading: Icon(
                                Icons.edit,
                                color: Colors.white,
                                size: 25,
                              ),
                              title: Text('Edit Profile',
                                  style: TextStyle(color: Colors.white)),
                              onTap: () async {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => EditProfilePage(
                                            profileDetails:
                                                snapshot.data?.docs[0])));
                              },
                            ),
                            ListTile(
                              leading: Icon(
                                Icons.logout,
                                color: Colors.white,
                                size: 25,
                              ),
                              title: Text('Logout',
                                  style: TextStyle(color: Colors.white)),
                              onTap: () async {
                                final GoogleSignIn _googleSignIn =
                                    GoogleSignIn();
                                await FirebaseAuth.instance.signOut();
                                await _googleSignIn.signOut();
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => RootScreen()));

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("Logged Out"),
                                  ),
                                );
                              },
                            )
                          ],
                        ),
                      ),
                backgroundColor: Colors.white,
                body: TabBarView(
                  children: [
                    // tab one view
                    SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 30,
                          ),
                          StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection('events')
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                // String data = snapshot.data.toString();
                                if (!snapshot.hasData) return SizedBox();
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children:
                                      snapshot.data!.docs.map((eventDetails) {
                                    List<String> reportList =
                                        List.from(eventDetails['reportList']);

                                    return Container(
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                        border: Border.all(
                                          color: kDark,
                                          width: 1,
                                        ),
                                        color: kWhite,
                                        boxShadow: [
                                          BoxShadow(
                                            color: kCyan,
                                            spreadRadius: 1,
                                            blurRadius: 1,
                                            // offset: Offset(0, 0), // changes position of shadow
                                          ),
                                        ],
                                      ),
                                      margin: EdgeInsets.only(
                                          left: 30,
                                          top: MediaQuery.of(context)
                                                  .viewPadding
                                                  .top +
                                              17,
                                          right: 30),
                                      //  padding: EdgeInsets.only(left: 10,top: 10),
                                      // color: Colors.white,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text("Event Name",
                                                  style: kTextHeadingStyle(
                                                      17, kBlack)),
                                              Spacer(),
                                              reportList.length > 0
                                                  ? Text("Reported By Users",
                                                      style: kTextHeadingStyle(
                                                          14, kRed))
                                                  : SizedBox(),
                                              SizedBox(
                                                width: 10,
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                eventDetails['eventName']
                                                    .toString()
                                                    .capitalizeFirst!,
                                                style: kTextNormalStyle(
                                                    14, kDarkGrey),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text("Event Place",
                                                  style: kTextHeadingStyle(
                                                      17, kBlack)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                  eventDetails['eventPlace']
                                                      .toString()
                                                      .capitalizeFirst!,
                                                  style: kTextNormalStyle(
                                                      14, kDarkGrey)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text("Event Price",
                                                  style: kTextHeadingStyle(
                                                      17, kBlack)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                  "€ " +
                                                      eventDetails['eventPrice']
                                                          .toString()
                                                          .capitalizeFirst!,
                                                  style: kTextNormalStyle(
                                                      14, kDarkGrey)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text("Event Date",
                                                      style: kTextHeadingStyle(
                                                          17, kBlack)),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                      DateFormat.yMMMEd()
                                                          .format(eventDetails[
                                                                  'eventDate']
                                                              .toDate())
                                                          .toString()!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey)),
                                                ],
                                              ),
                                              Spacer(),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text("Event Time",
                                                      style: kTextHeadingStyle(
                                                          17, kBlack)),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                      eventDetails[
                                                                  'eventType'] ==
                                                              "personal"
                                                          ? DateFormat('HH:mm')
                                                              .format(eventDetails[
                                                                      'eventDate']
                                                                  .toDate())
                                                              .toString()
                                                              .capitalizeFirst!
                                                          : eventDetails[
                                                                  'eventTime']
                                                              .toString()
                                                              .capitalizeFirst!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey)),
                                                ],
                                              ),
                                              SizedBox(
                                                width: 15,
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Container(
                                                height: 50,
                                                decoration: BoxDecoration(
                                                  //   color: Color.fromRGBO(104, 121, 137, 1),
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(10)),
                                                ),
                                                child: Center(
                                                  child: IconButton(
                                                    onPressed: () {
                                                      FirebaseFirestore.instance
                                                          .collection('events')
                                                          .doc(eventDetails.id)
                                                          .delete();
                                                    },
                                                    icon: const Icon(
                                                      Icons.delete_forever,
                                                      size: 35,
                                                      color: Colors.cyan,
                                                    ),
                                                  ),
                                                  //   alignment:Alignment.center
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 15,
                                          )
                                        ],
                                      ),
                                    );
                                    //if search is less then 3 characters
                                  }).toList(),
                                );
                              }),
                          const SizedBox(
                            height: 20,
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ),

                    //tab 2 view
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection('lectures')
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                // String data = snapshot.data.toString();
                                if (!snapshot.hasData) return SizedBox();
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children:
                                      snapshot.data!.docs.map((lectureDetails) {
                                    //  List<String> imageUrls =List.from(userDocument['picUrl']);

                                    return Container(
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                        border: Border.all(
                                          color: kDark,
                                          width: 1,
                                        ),
                                        color: kWhite,
                                        boxShadow: [
                                          BoxShadow(
                                            color: kCyan,
                                            spreadRadius: 1,
                                            blurRadius: 1,
                                            // offset: Offset(0, 0), // changes position of shadow
                                          ),
                                        ],
                                      ),
                                      margin: EdgeInsets.only(
                                          left: 30,
                                          top: MediaQuery.of(context)
                                                  .viewPadding
                                                  .top +
                                              17,
                                          right: 30),
                                      //  padding: EdgeInsets.only(left: 10,top: 10),
                                      // color: Colors.white,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text("Lecture Name",
                                                  style: kTextHeadingStyle(
                                                      17, kBlack)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                lectureDetails['lectureName']
                                                    .toString()
                                                    .capitalizeFirst!,
                                                style: kTextNormalStyle(
                                                    14, kDarkGrey),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text("Lecture Place",
                                                  style: kTextHeadingStyle(
                                                      17, kBlack)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                  lectureDetails['lecturePlace']
                                                      .toString()
                                                      .capitalizeFirst!,
                                                  style: kTextNormalStyle(
                                                      14, kDarkGrey)),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text("Lecture Date",
                                                      style: kTextHeadingStyle(
                                                          17, kBlack)),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                      DateFormat.yMMMEd()
                                                          .format(lectureDetails[
                                                                  'lectureDate']
                                                              .toDate())
                                                          .toString()!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey)),
                                                ],
                                              ),
                                              Spacer(),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text("Lecture Time",
                                                      style: kTextHeadingStyle(
                                                          17, kBlack)),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                      lectureDetails[
                                                              'lectureTime']
                                                          .toString()
                                                          .capitalizeFirst!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey)),
                                                ],
                                              ),
                                              SizedBox(
                                                width: 15,
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Container(
                                                height: 50,
                                                decoration: BoxDecoration(
                                                  //   color: Color.fromRGBO(104, 121, 137, 1),
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(10)),
                                                ),
                                                child: Center(
                                                  child: IconButton(
                                                    onPressed: () {
                                                      FirebaseFirestore.instance
                                                          .collection(
                                                              'lectures')
                                                          .doc(
                                                              lectureDetails.id)
                                                          .delete();
                                                    },
                                                    icon: const Icon(
                                                      Icons.delete_forever,
                                                      size: 35,
                                                      color: Colors.cyan,
                                                    ),
                                                  ),
                                                  //   alignment:Alignment.center
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 15,
                                          )
                                        ],
                                      ),
                                    );
                                    //if search is less then 3 characters
                                  }).toList(),
                                );
                              }),
                          SizedBox(
                            height: 25,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ));
        });
  }
}
