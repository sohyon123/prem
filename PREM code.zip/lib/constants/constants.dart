import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:intl/intl.dart';

//class has the constants used in the code
//if the color/theme of the app is changed it can be done though here
TextStyle kBodyText = const TextStyle(fontSize: 15, color: Colors.white);
TextStyle kButtonText = const TextStyle(
    fontSize: 14, color: Colors.black, fontWeight: FontWeight.bold);

Color kWhite = Colors.white;
Color kDarkGrey = Colors.grey;
Color kBlack = const Color(0xFF060807);
Color kGreen = const Color(0xFFD0FD3E);
Color kRed = const Color(0xFFFF2424);ia
Color kCyan = Colors.cyan;
Color kTrans = Colors.transparent;
Color kGrey = const Color(0xFFD2D6DB);
Color kLightGrey = kWhite.withOpacity(0.5);
Color kDark = const Color(0xFF2C2C2E);
Color kBlue = const Color(0xFF1294F2);
TextStyle kTextHeadingStyle(double size, Color fontColor) {
  return TextStyle(
      fontSize: size, color: fontColor, fontWeight: FontWeight.bold);
}

TextStyle kTextNormalStyle(double size, Color fontColor) {
  return TextStyle(
      fontSize: size, color: fontColor, fontWeight: FontWeight.w400);
}

var brightness = SchedulerBinding.instance.window.platformBrightness;
bool isDarkMode = brightness == Brightness.dark;

String formattingTimeOfDay(TimeOfDay timeOfDay) {
  final now = DateTime.now();
  final date = DateTime(
    now.year,
    now.month,
    now.day,
    timeOfDay.hour,
    timeOfDay.minute,
  );
  final format = DateFormat.jm();
  return format.format(date);
}
