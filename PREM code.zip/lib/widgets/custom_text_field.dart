import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../constants/constants.dart';

class CustomTextField extends StatelessWidget {
  final String nHintText;
  final String? Function(String?)? validator;
  final TextEditingController controller;
  final TextInputAction inputAction;
  final TextInputType inputType;
  final double? verticalPadding;
  final Color? fillColor;
  final List<TextInputFormatter>? inputFormatter;
  const CustomTextField(
      {Key? key,
      required this.controller,
      required this.nHintText,
      required this.inputAction,
      required this.inputType,
      this.validator,
      this.inputFormatter,
      this.verticalPadding,
      this.fillColor})
      : super(key: key);
//this class is for the text fields used though out the code
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: TextFormField(
            controller: controller,
            cursorColor: kBlack,
            style: kBodyText.copyWith(color: kBlack),
            textInputAction: inputAction,
            inputFormatters: inputFormatter,
            keyboardType: inputType,
            decoration: InputDecoration(
              fillColor: fillColor ?? kLightGrey,
              filled: true,
              contentPadding: EdgeInsets.symmetric(
                  vertical: verticalPadding ?? 18, horizontal: 20),
              hintText: nHintText,
              hintStyle: kBodyText.copyWith(color: kBlack),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(
                  color: kLightGrey,
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(
                  color: kCyan,
                  width: 1,
                ),
              ),
            ),
            validator: validator),
      ),
    );
  }
}
