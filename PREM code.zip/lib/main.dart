

import 'package:evenmanagment/services/notification_service.dart';
import 'package:evenmanagment/splash.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:page_transition/page_transition.dart';




void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final NotificationService _notificationService = NotificationService();

  await Firebase.initializeApp(
    //options: DefaultFirebaseOptions.currentPlatform,
  );
  _notificationService.initNotification();
  _notificationService.requestIOSPermission();

   runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return

      GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PREM',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/second':
            return PageTransition(
              child: SplashPage(),
              type: PageTransitionType.rotate,
              settings: settings,
              reverseDuration: Duration(seconds: 3),
            );
            break;
          default:
            return null;
        }
      },
      theme: ThemeData(

        primarySwatch: Colors.cyan,
      ),
      home: const SplashPage(),
    );
  }
}
