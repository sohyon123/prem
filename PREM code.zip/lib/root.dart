import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:evenmanagment/eventPlannner/eventHomePage.dart';
import 'package:evenmanagment/student/studentHomePage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:evenmanagment/authentication/signin.dart';
import 'admin/adminHomePage.dart';
import 'authentication/googleSignUpUserInformationScreen.dart';
import 'lecturer/lecturerHomePage.dart';

class RootScreen extends StatefulWidget {


  
  @override
  State<StatefulWidget> createState() => new _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {

  @override
  Widget build(BuildContext context) {
// this stream checks if user is logged in or not
     return WillPopScope(
       onWillPop: (){

         return Future.value(false);
       },
       child: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.userChanges(),
        initialData: FirebaseAuth.instance.currentUser,
        builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
          // Check if user is logged in
          final String? uid = snapshot.data?.uid ?? null;

          if (uid != null)
            //stream checks if user already logged in or not for now we have commented instrcutions screen
            return StreamBuilder(

                stream: FirebaseFirestore.instance
                    .collection('userDetails').where("userId",isEqualTo: FirebaseAuth.instance.currentUser!.uid ).limit(1)
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshots) {
                  // String data = snapshot.data.toString();
                  if (!snapshots.hasData)
                    return GoogleSignUpUserInformationForm();
                  return
                
                                        snapshots!.data!.docs[0]["userType"]==""?
                                          GoogleSignUpUserInformationForm():
                                            snapshots!.data!.docs[0]["userType"]=="Student"?
                                            StudentsHomePage()
                                     // StudentEventsPage()
                                            :
                                      snapshots.data?.docs[0]["userType"]=="Lecturer"?
                                      LecturerHomePage()
                                    :
                                snapshots.data?.docs[0]["userType"]=="Event Planner"?
                                EventHomePage()
                                    :
                                AdminHomePage();

              }
            );

          return siginPage();
        },
    ),
     );
  }
}
