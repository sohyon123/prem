import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:evenmanagment/constants/constants.dart';
import 'package:evenmanagment/eventPlannner/addEvent.dart';
import 'package:evenmanagment/eventPlannner/viewEvents.dart';
import 'package:evenmanagment/root.dart';
import 'package:evenmanagment/widgets/custom_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'dart:core';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../profile/editProfile.dart';

class EventHomePage extends StatefulWidget {


  EventHomePage({super.key, required, });



  @override
  State<EventHomePage> createState() => _EventHomePageState();
}

class _EventHomePageState extends State<EventHomePage>
    with WidgetsBindingObserver

{

  @override


  @override
  Widget build(BuildContext context) {
    // this stream gets user details like name coins etc
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('userDetails').where("userId",isEqualTo: FirebaseAuth.instance.currentUser!.uid ).limit(1)
            .snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<QuerySnapshot> snapshot) {
          // String data = snapshot.data.toString();
          if (!snapshot.hasData)
            return SizedBox();
        return Scaffold(

appBar: AppBar(title: Text("PREM"),),
backgroundColor: Colors.white,
             drawer:  !snapshot.hasData?SizedBox(): Drawer(
               backgroundColor: kCyan,
               child: ListView(
                 padding: EdgeInsets.zero,
                 children: <Widget>[
                   DrawerHeader(

                       decoration:  BoxDecoration(

                         color: kCyan,
                       ),
                       child:
                       Column(

                         mainAxisAlignment: MainAxisAlignment.center,
                         crossAxisAlignment: CrossAxisAlignment.center,
                         children: [



                           // SizedBox(height: 5,),
                           Text("Welcome! "+snapshot.data?.docs[0]['name'],style: TextStyle(fontSize: 17,fontWeight: FontWeight.bold,color: Colors.white),),
                           //   SizedBox(height: 5,),



                         ],)
                   ),
                   ListTile(
                     leading: Icon(
                       Icons.edit,
                       color: Colors.white,
                       size: 25,
                     ),
                     title:
                     Text('Edit Profile', style:TextStyle(color: Colors.white)),
                     onTap: () async {

          Navigator.push(context, MaterialPageRoute(
          builder: (context) => EditProfilePage(profileDetails: snapshot.data?.docs[0])));

                     },
                   ),

                   ListTile(
                     leading: Icon(
                       Icons.logout,
                       color: Colors.white,
                       size: 25,
                     ),
                     title:
                     Text('Logout', style:TextStyle(color: Colors.white)),
                     onTap: () async {


                       final GoogleSignIn _googleSignIn = GoogleSignIn();
                       await FirebaseAuth.instance.signOut();
                       await _googleSignIn.signOut();
                       Navigator.pushReplacement(
                           context,
                           MaterialPageRoute(
                               builder: (context) =>RootScreen()));


                       ScaffoldMessenger.of(context).showSnackBar(
                         SnackBar(
                           content: Text("Logged Out"),
                         ),
                       );
                     },
                   )

                 ],
               ),
             ),
          body:
          !snapshot.hasData?
          SingleChildScrollView(
            child: Container(
              height: Get.height,
              child: Center(child:
              CircularProgressIndicator(color: kCyan,strokeWidth: 5,)),
            ),
          )

              :
          SingleChildScrollView(
                child: Column(children: [




                  SizedBox(height: 20,),
            Center(
              child: CustomButton(
                color: kCyan,
                  title: "Add New Event",
                  onTap: () {

                    Get.to(() => AddEventScreen());

                  }),
            ),

          const SizedBox(height: 20,),

                  Center(
                    child: CustomButton(
                        color: kCyan,
                        title: "Edit/View Event",
                        onTap: () {

                            Get.to(() => ViewEvent());

                        }),
                  ),

                  const SizedBox(height: 20,),





                ],),
              )



         // This trailing comma makes auto-formatting nicer for build methods.
        );
      }
    );

  }


}
