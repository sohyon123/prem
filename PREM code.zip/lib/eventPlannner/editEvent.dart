import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../constants/constants.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';

class EditEventScreen extends StatefulWidget {
  var eventDetails;
  EditEventScreen({super.key, required this.eventDetails});

  @override
  State<EditEventScreen> createState() => _EditEventScreenState();
}

class _EditEventScreenState extends State<EditEventScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController placeController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  final formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }

  double? verticalPadding;
  Color? fillColor;
  bool isLoading = false;
  List<String> selected = [];
  var selectedTime;
  var previousTime;
  _chooseTime(BuildContext context) async {
    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      selectedTime = pickedTime;
    }
    ;
    setState(() {});
  }

  void initState() {
    setState(() {
      nameController.text = widget.eventDetails['eventName'];
      placeController.text = widget.eventDetails['eventPlace'];
      priceController.text = widget.eventDetails['eventPrice'];
      previousTime = widget.eventDetails['eventTime'];
      selectedDate = widget.eventDetails['eventDate'].toDate();
    });

    super.initState();
  }

  DateTime? selectedDate;

  _selectDate(BuildContext context) async {
    var date = new DateTime.now();
    var newDate = new DateTime(date.year, date.month, date.day + 1);

    selectedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(Duration(days: 1)),
      firstDate: DateTime.now().add(Duration(days: 1)),
      lastDate: DateTime(2024),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: kBlack, // <-- SEE HERE
              onPrimary: kGrey, // <-- SEE HERE
              onSurface: kBlack, // <-- SEE HERE
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                primary: kBlack, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    );
    setState(() {});
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: kWhite,
      appBar: PreferredSize(
        child: Container(
          decoration: BoxDecoration(color: kWhite, boxShadow: [
            BoxShadow(
              color: kCyan,
              offset: Offset(0, 2.0),
              blurRadius: 4.0,
            )
          ]),
          child: AppBar(
            backgroundColor: kWhite,
            elevation: 0.0,
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.cyanAccent.shade700,
              ),
            ),
            title: Text("Edit event details"),
          ),
        ),
        preferredSize: Size.fromHeight(kToolbarHeight),
      ),
      body: isLoading
          ? Center(
              child: SpinKitSpinningLines(color: kCyan),
            )
          : SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 30,
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 22, bottom: 5),
                        child: Text(
                          "Event Name",
                          style: TextStyle(color: kBlack, fontSize: 16),
                        )),
                    CustomTextField(
                      validator: (value) {
                        if (value == "") {
                          return "Please enter event name ";
                        }
                      },
                      inputAction: TextInputAction.done,
                      inputType: TextInputType.text,
                      controller: nameController,
                      nHintText: 'Event Name',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 22, bottom: 5),
                        child: Text(
                          "Event Place",
                          style: TextStyle(color: kBlack, fontSize: 16),
                        )),
                    CustomTextField(
                      validator: (value) {
                        if (value == "") {
                          return "Please enter event place ";
                        }
                      },
                      inputAction: TextInputAction.done,
                      inputType: TextInputType.text,
                      controller: placeController,
                      nHintText: 'Event Place',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 22, bottom: 5),
                        child: Text(
                          "Event Price (€)",
                          style: TextStyle(color: kBlack, fontSize: 16),
                        )),
                    CustomTextField(
                      validator: (value) {
                        if (value == "") {
                          return "Please enter event price ";
                        }
                      },
                      inputFormatter: <TextInputFormatter>[
                        // for below version 2 use this
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
// for version 2 and greater youcan also use this
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(6),
                      ],
                      inputAction: TextInputAction.done,
                      inputType: TextInputType.number,
                      controller: priceController,
                      nHintText: 'Event Price',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 22, bottom: 5),
                        child: Text(
                          "Select Date",
                          style: TextStyle(color: kBlack, fontSize: 16),
                        )),
                    InkWell(
                      onTap: () {
                        _selectDate(context);
                      },
                      child: Center(
                        child: Container(
                          width: Get.width,
                          height: 50,
                          margin: EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 15),
                          decoration: BoxDecoration(
                            color: kLightGrey,
                            borderRadius:
                                BorderRadius.all(Radius.circular(8.0)),
                            border: Border.all(
                              color: kDark,
                              width: 1,
                            ),
                          ),
                          //width: Get.width*0.75,

                          child: Text(
                            selectedDate != null
                                ? DateFormat.yMMMEd()
                                    .format(selectedDate!)
                                    .toString()
                                : "Select Date",
                            style: TextStyle(color: kBlack, fontSize: 15),
                          ),
                          // padding: EdgeInsets.only(top: 10),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 22, bottom: 5),
                        child: Text(
                          "Choose event Time",
                          style: TextStyle(color: kBlack, fontSize: 16),
                        )),
                    InkWell(
                      onTap: () {
                        _chooseTime(context);
                      },
                      child: Center(
                        child: Container(
                          width: Get.width,
                          height: 50,
                          margin: EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 15),
                          decoration: BoxDecoration(
                            color: kLightGrey,
                            borderRadius:
                                BorderRadius.all(Radius.circular(8.0)),
                            border: Border.all(
                              color: kDark,
                              width: 1,
                            ),
                          ),
                          //width: Get.width*0.75,

                          child: Text(
                            selectedTime != null
                                ? formattingTimeOfDay(selectedTime)
                                : previousTime,
                            style: TextStyle(color: kBlack, fontSize: 15),
                          ),
                          // padding: EdgeInsets.only(top: 10),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: CustomButton(
                          color: kCyan,
                          title: "Update event",
                          onTap: () {
                            if (formKey.currentState!.validate()) {
                              if (selectedDate == null) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: Colors.white,
                                    content: Text(
                                      "Please choose date",
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                );
                              } else {
                                setState(() {
                                  isLoading = true;
                                });
                                updateeventDetails();
                              }
                            }
                          }),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  XFile? imageFile;
  updateeventDetails() async {
    final dateWithTime = DateTime(selectedDate!.year, selectedDate!.month,
        selectedDate!.day, selectedTime!.hour, selectedTime!.minute);

    await FirebaseFirestore.instance
        .collection('events')
        .doc(widget.eventDetails.id)
        .update({
      "eventName": nameController.text,
      'eventPlace': placeController.text,
      'eventTime': formattingTimeOfDay(selectedTime),
      'eventDate': dateWithTime,
    }).catchError((e) {
      print(e);
    }).whenComplete(() async => {
              await ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  backgroundColor: Colors.grey,
                  content: Text("event Added"),
                ),
              ),
              Navigator.pop(context)
            });
  }
}
