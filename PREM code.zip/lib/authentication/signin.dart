import 'dart:core';

import 'package:evenmanagment/authentication/signup.dart';
import 'package:evenmanagment/root.dart';
import 'package:evenmanagment/widgets/custom_button.dart';
import 'package:evenmanagment/widgets/custom_text_field.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/route_manager.dart';

import '../constants/constants.dart';
import 'googleSignIn.dart';

class siginPage extends StatefulWidget {
  const siginPage({super.key, required});

  @override
  State<siginPage> createState() => _siginPageState();
}

class _siginPageState extends State<siginPage> {
  TextEditingController emailController = TextEditingController();
  final passwordController = TextEditingController();
  // for pin

  bool loading = false;

  String currentText = "";
  final formKey = GlobalKey<FormState>();
  bool isLoading = false;
  @override
  void initState() {
    super.initState();
  }

  // bool isPin=false;
  @override
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        return Future.value(false);
      },
      child: Scaffold(
          appBar: AppBar(
            leading: SizedBox(),
            title: Text("                Signin"),
          ),
          backgroundColor: kWhite,
          body: isLoading
              ? SingleChildScrollView(
                  child: Container(
                    height: Get.height,
                    child: Center(
                      child: SpinKitSpinningLines(color: kCyan),
                    ),
                  ),
                )
              : Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 50,
                        ),
                        Container(
                          child: Container(
                              height: Get.height,
                              width: Get.width,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Center(
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: 30,
                                        ),
                                        Text(
                                          "Welcome Back!",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 25),
                                        ),
                                        SizedBox(
                                          height: 15,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomTextField(
                                          validator: (input) {
                                            String? pattern =
                                                r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                            RegExp regex = new RegExp(pattern);
                                            if (input!.trim().isEmpty) {
                                              return 'Please enter a valid email';
                                            } else if (!regex.hasMatch(input))
                                              return 'Please enter a valid email';
                                            else
                                              return null;
                                          },
                                          inputAction: TextInputAction.done,
                                          inputType: TextInputType.text,
                                          controller: emailController,
                                          nHintText: 'Email',
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomTextField(
                                          validator: (value) {
                                            if (value == "") {
                                              return "Please enter password ";
                                            }
                                          },
                                          inputAction: TextInputAction.done,
                                          inputType: TextInputType.text,
                                          controller: passwordController,
                                          nHintText: 'Password',
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomButton(
                                            color: kCyan,
                                            title: "SignIn",
                                            onTap: () {
                                              if (_formKey.currentState!
                                                  .validate()) {
                                                setState(() {
                                                  isLoading = true;
                                                });

                                                loginWithEmail(
                                                    email: emailController.text,
                                                    password:
                                                        passwordController.text,
                                                    context: context);
                                              }
                                            }),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text('OR',
                                            style: TextStyle(
                                              color: Colors.black54,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        InkWell(
                                          onTap: () async {
                                            print("adf");
                                            setState(() {
                                              isLoading = true;
                                            });
                                            GoogleFirebaseService service =
                                                new GoogleFirebaseService();
                                            try {
                                              await service
                                                  .signInwithGoogle(context);
                                              print("LoggedIn");
                                            } catch (e) {
                                              if (e is FirebaseAuthException) {
                                                setState(() {
                                                  isLoading = true;
                                                });
                                                showMessage(e.message!);
                                              }
                                            }
                                            setState(() {
                                              isLoading = false;
                                            });
                                          },
                                          child: Container(
                                            child: Image.asset(
                                                "assets/google.png"),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SignUpPage()));
                                          },
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                    text:
                                                        'Don’t have an account? ',
                                                    style: TextStyle(
                                                      color: Colors.black54,
                                                      fontSize: 16,
                                                    ),
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                        text: 'Register',
                                                        style: TextStyle(
                                                          color: kCyan,
                                                          fontSize: 16,
                                                        ),
                                                      ),
                                                    ]),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              )),
                        ),
                      ],
                    ),
                  ),
                )),
    );
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? verificationId;
  String? otp, authStatus = "";

  Future<void> loginWithEmail({
    required String email,
    required String password,
    required BuildContext context,
  }) async {
    try {
      await FirebaseAuth.instance
          .signInWithEmailAndPassword(
        email: email,
        password: password,
      )
          .then((value) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Logged In Successfully"),
          ),
        );
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => RootScreen()));
      });
      //if the email/password does not match with something in firebase
    } on FirebaseAuthException catch (e) {
      setState(() {
        this.loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Invalid email/password"),
        ),
      );
      setState(() {
        this.loading = false;
      }); // Displaying the error message
    }
  }

  bool nextScreen = false;
  void showMessage(String message) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Error"),
            content: Text(message),
            actions: [
              TextButton(
                child: Text("Ok"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }
}
