import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:evenmanagment/authentication/signin.dart';
import 'package:evenmanagment/constants/constants.dart';
import 'package:evenmanagment/root.dart';
import 'package:evenmanagment/widgets/custom_button.dart';
import 'package:evenmanagment/widgets/custom_text_field.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/route_manager.dart';

class SignUpPage extends StatefulWidget {
  SignUpPage({
    super.key,
    required,
  });

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

// do email and pass and name check
  final nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  final passwordController = TextEditingController();

  bool loading = false;

  bool isLoading = false;

  String? userType;
  List<String> userTypeList = ['Student', 'Lecturer', 'Event Planner', 'Admin'];
  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
        appBar: AppBar(
          title: Text("                Sign up"),
        ),
        backgroundColor: Colors.white,
        body: isLoading
            ? SingleChildScrollView(
                child: Container(
                  height: Get.height,
                  child: Center(
                    child: SpinKitSpinningLines(color: kCyan),
                  ),
                ),
              )
            : SingleChildScrollView(
                child: Container(
                  child: SingleChildScrollView(
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          Container(
                              //  margin: EdgeInsets.only(bottom:100 ),
                              //height:Get.height*0.80,
                              width: Get.width,
                              color: Colors.white,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Center(
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        SizedBox(
                                          height: 30,
                                        ),
                                        Text(
                                          "Let's get started",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 25),
                                        ),
                                        SizedBox(
                                          height: 15,
                                        ),
                                        CustomTextField(
                                          validator: (value) {
                                            if (value == "") {
                                              return "Please enter your name ";
                                            }
                                          },
                                          inputAction: TextInputAction.done,
                                          inputType: TextInputType.text,
                                          controller: nameController,
                                          nHintText: 'Name',
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomTextField(
                                          validator: (input) {
                                            String? pattern =
                                                r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                                            RegExp regex = new RegExp(pattern);
                                            if (input!.trim().isEmpty) {
                                              return 'Please enter a valid email';
                                            } else if (!regex.hasMatch(input))
                                              return 'Please enter a valid email';
                                            else
                                              return null;
                                          },
                                          inputAction: TextInputAction.done,
                                          inputType: TextInputType.text,
                                          controller: emailController,
                                          nHintText: 'Email',
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Container(
                                          width: Get.width,
                                          height: 50,
                                          margin: EdgeInsets.symmetric(
                                            horizontal: 20,
                                          ),
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 15),
                                          decoration: BoxDecoration(
                                            color: kLightGrey,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(8.0)),
                                            border: Border.all(
                                              color: kDark,
                                              width: 1,
                                            ),
                                          ),
                                          child: DropdownButton2(
                                            underline: SizedBox(),
                                            isExpanded: true,
                                            hint: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Select User Type',
                                                  style: kBodyText.copyWith(
                                                      color: kBlack),
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ],
                                            ),
                                            items: userTypeList
                                                .map((item) =>
                                                    DropdownMenuItem<String>(
                                                      value: item,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            item,
                                                            style: kBodyText
                                                                .copyWith(
                                                                    color:
                                                                        kBlack),
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                        ],
                                                      ),
                                                    ))
                                                .toList(),
                                            value: userType,
                                            onChanged: (value) {
                                              setState(() {
                                                if (userType != value) {
                                                  userType = userType =
                                                      value as String;
                                                }
                                              });
                                            },
                                            icon: const Icon(
                                              Icons.arrow_drop_down_outlined,
                                            ),
                                            iconSize: 20,
                                            iconEnabledColor: Colors.black45,
                                            iconDisabledColor: Colors.grey,
                                            buttonPadding:
                                                const EdgeInsets.only(
                                                    left: 15, right: 15),
                                            buttonElevation: 2,
                                            itemHeight: 40,
                                            itemPadding: const EdgeInsets.only(
                                                left: 15, right: 15),
                                            dropdownMaxHeight: 200,
                                            dropdownWidth: 200,
                                            dropdownPadding: null,
                                            dropdownDecoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        15.0),
                                                boxShadow: [
                                                  BoxShadow(
                                                      color: Color.fromRGBO(
                                                          243, 243, 245, 1),
                                                      blurRadius: 4.0,
                                                      spreadRadius: 0.4)
                                                ]),
                                            dropdownElevation: 8,
                                            scrollbarRadius:
                                                const Radius.circular(40),
                                            scrollbarThickness: 6,
                                            scrollbarAlwaysShow: true,
                                            offset: const Offset(-20, 0),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomTextField(
                                          validator: (value) {
                                            if (value == "") {
                                              return "Please enter password ";
                                            }
                                          },
                                          inputAction: TextInputAction.done,
                                          inputType: TextInputType.text,
                                          controller: passwordController,
                                          nHintText: 'Password',
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        CustomButton(
                                            color: kCyan,
                                            title: "Signup",
                                            onTap: () {
                                              if (_formKey.currentState!
                                                  .validate()) {
                                                if (userType == null) {
                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(
                                                    SnackBar(
                                                      backgroundColor:
                                                          Colors.red,
                                                      content: Text(
                                                          "Please select User Type"),
                                                    ),
                                                  );
                                                } else {
                                                  setState(() {
                                                    isLoading = true;
                                                  });
                                                  signUpWithEmail(
                                                      context: context,
                                                      name: nameController.text,
                                                      email:
                                                          emailController.text,
                                                      password:
                                                          passwordController
                                                              .text,
                                                      userType: userType!);
                                                }
                                              }
                                            }),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            RichText(
                                              text: TextSpan(
                                                  text:
                                                      'Already have an account?',
                                                  style: TextStyle(
                                                    color: Colors.black54,
                                                    fontSize: 16,
                                                  ),
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                      text: ' SignIn',
                                                      style: TextStyle(
                                                        color: kCyan,
                                                        fontSize: 16,
                                                      ),
                                                      recognizer:
                                                          TapGestureRecognizer()
                                                            ..onTap = () async {
                                                              Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                      builder:
                                                                          (context) =>
                                                                              siginPage()));
                                                            },
                                                    ),
                                                  ]),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              )

        // This trailing comma makes auto-formatting nicer for build methods.
        );
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final db = FirebaseFirestore.instance;
  Future<void> signUpWithEmail({
    required BuildContext context,
    required String name,
    required String email,
    required String password,
    required String userType,
  }) async {
    try {
      Timestamp currentTime = Timestamp.now();

      await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: email,
        password: password,
      )
          .then((uID) async {
        await db.collection("userDetails").doc(uID.user?.uid.toString()).set({
          'name': name,
          'userId': uID.user?.uid.toString(),
          'email': emailController.text,
          'userType': userType,
          'timestamp': currentTime,
        }).whenComplete(() => {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text("You have successfully registered"),
                ),
              ),
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => RootScreen()))
            });

        return uID.user?.uid.toString();
      });
    } on FirebaseAuthException catch (e) {
      // error message can be changed here
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.message!),
        ),
      ); //; // Displaying the usual firebase error message
    }
  }

  bool nextScreen = false;
}
