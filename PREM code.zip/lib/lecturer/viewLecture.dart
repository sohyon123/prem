import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:evenmanagment/lecturer/addLecture.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../constants/constants.dart';
import '../widgets/custom_button.dart';
import 'editLecture.dart';

class ViewLectures extends StatefulWidget {
  const ViewLectures({super.key});

  @override
  State<ViewLectures> createState() => _ViewLecturesState();
}

class _ViewLecturesState extends State<ViewLectures> {
  final TextEditingController nameController = TextEditingController();
  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhite,
      appBar: AppBar(
        title: Text(
          "Your Lectures",
         // style: kBodyText.copyWith(fontWeight: FontWeight.bold, fontSize: 25),
        ),
        centerTitle: true,
        backgroundColor: kWhite,
      ),
      body: SingleChildScrollView(

        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

const SizedBox(height: 30,),

            StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('lectures')
                    .where('eventrId', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  // String data = snapshot.data.toString();
                  if (!snapshot.hasData)
                    return SizedBox();
                  return
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: snapshot.data!.docs.map((lectureDetails) {
                              //  List<String> imageUrls =List.from(userDocument['picUrl']);

                              return

                                Container(
                                  decoration:  BoxDecoration(
                                    borderRadius:  BorderRadius.circular(15.0),
                                    border: Border.all(
                                      color: kDark,
                                      width: 1,
                                    ),
                                    color: kWhite,

                                    boxShadow: [
                                      BoxShadow(
                                        color: kCyan,
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                       // offset: Offset(0, 0), // changes position of shadow
                                      ),
                                    ],

                                  ),
                                  margin: EdgeInsets.only(left: 30,top:  MediaQuery.of(context).viewPadding.top+17,right: 30),
                                //  padding: EdgeInsets.only(left: 10,top: 10),
                                 // color: Colors.white,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      SizedBox(height: 10,),
                                      Row(
                                        children: [
                                          SizedBox(width: 10,),

                                          Text("Lecture Name",style:
                                          kTextHeadingStyle(17,kBlack)
                                             ),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                        Row(
                                          children: [
                                           SizedBox(width: 10,),

                                            Text( lectureDetails['lectureName'].toString().capitalizeFirst!,style:
                                            kTextNormalStyle(14,kDarkGrey),),
                                          ],
                                        ),
                                      SizedBox(height: 5,),
                                      Row(
                                        children: [
                                          SizedBox(width: 10,),

                                          Text("Lecture Place",style: kTextHeadingStyle(17,kBlack)),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                      Row(
                                        children: [
                                          SizedBox(width: 10,),

                                          Text( lectureDetails['lecturePlace'].toString().capitalizeFirst!,style:

                                          kTextNormalStyle(14,kDarkGrey)
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                      Row(
                                        children: [
                                          SizedBox(width: 10,),

                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text("Lecture Date",style:kTextHeadingStyle(17,kBlack)),
                                              SizedBox( height: 5,),
                                              Text( DateFormat.yMMMEd().format(lectureDetails['lectureDate'].toDate()).toString()!,style:

                                              kTextNormalStyle(14,kDarkGrey)

                                              ),
                                            ],
                                          ),
                                          Spacer(),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text("Lecture Time",style: kTextHeadingStyle(17,kBlack)),
                                              SizedBox(height: 5,),
                                              Text( lectureDetails['lectureTime'].toString().capitalizeFirst!,style:

                                              kTextNormalStyle(14,kDarkGrey)
                                              ),
                                            ],
                                          ),
                                          SizedBox(width: 15,)
                                        ],
                                      ),


                                      SizedBox(height: 10,),

                                      Row(

                                        children: [
SizedBox(width: 5,),
                                          Container(
                                            height: 50,


                                            decoration: BoxDecoration(

                                              //   color: Color.fromRGBO(104, 121, 137, 1),
                                              borderRadius: BorderRadius.all(Radius.circular(10)),
                                            ),
                                            child: Center(

                                              child: IconButton(

                                                onPressed: (


                                                    ) {

                                                  Get.to(() => EditLectureScreen(  lectureDetails: lectureDetails,));

                                                },

                                                icon: const Icon(
                                                  Icons.edit,


                                                  size: 35,
                                                  color: Colors.cyan,

                                                ),

                                              ),
                                              //   alignment:Alignment.center
                                            ),
                                          ),

Spacer(),
                              Container(
                                height: 50,


                              decoration: BoxDecoration(

                              //   color: Color.fromRGBO(104, 121, 137, 1),
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              ),
                              child: Center(

                              child: IconButton(

                              onPressed: (


                              ) {
                              FirebaseFirestore.instance
                                  .collection('lectures')
                                  .doc(lectureDetails.id).delete();

                              },

                              icon: const Icon(
                              Icons.delete_forever,


                              size: 35,
                              color: Colors.cyan,

                              ),

                              ),
                              //   alignment:Alignment.center
                              ),
                              ),
                                          SizedBox(width: 10,)

                                        ],
                                      ),
                                      SizedBox(height: 15,)
                                    ],
                                  ),
                                );
                              //if search is less then 3 characters
                            }).toList(),
                          );
                }),
            const SizedBox(height: 20,),


            const SizedBox(height: 20,),
           
          ],
        ),
      ),
    );
  }
}
