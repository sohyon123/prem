import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:evenmanagment/constants/constants.dart';
import 'package:evenmanagment/lecturer/addLecture.dart';
import 'package:evenmanagment/lecturer/viewLecture.dart';
import 'package:evenmanagment/profile/editProfile.dart';
import 'package:evenmanagment/root.dart';
import 'package:evenmanagment/widgets/custom_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../constants/Utiles.dart';
import '../eventPlannner/addEvent.dart';

class LecturerHomePage extends StatefulWidget {
  LecturerHomePage({
    super.key,
    required,
  });

  @override
  State<LecturerHomePage> createState() => _LecturerHomePageState();
}

class _LecturerHomePageState extends State<LecturerHomePage> {
  bool isDateSame(DateTime eventDate) {
    if (_focusedDay.year == eventDate.year &&
        _focusedDay.month == eventDate.month &&
        _focusedDay.day == eventDate.day) {
      return true;
    } else {
      return false;
    }
  }

  List<DateTime> events = [];
  late final ValueNotifier<List<Event>> _selectedEvents;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOff; // Can be toggled on/off by long pressing a date
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  bool check = false;
  @override
  void initState() {
    super.initState();

    _selectedDay = _focusedDay;
    _selectedEvents = ValueNotifier(_getEventsForDay(_selectedDay!));
    //events
    Future.delayed(Duration(seconds: 3), () async {
      setState(() {
        this.check = true;
      });
    });
    FirebaseFirestore.instance
        .collection('events')
        .where("participantList",
            arrayContains: FirebaseAuth.instance.currentUser!.uid)
        .snapshots()
        .map((QuerySnapshot snapshot) {
      print(snapshot.size.toString() + "asdasdq22");

      for (int i = 0; i < snapshot.size; i++) {
        Timestamp t = snapshot.docs[i]['eventDate'];
        DateTime d = t.toDate();
        print(d);
        setState(() {
          events.add(d);
        });

        // print(snapshot.docs[i]['createdAt'].toString()+i.toString() + "asdsadda");
      }
    }).single;
    super.initState();
  }

  void updateEventList() {
    setState(() {
      FirebaseFirestore.instance
          .collection('events')
          .where("participantList",
              arrayContains: FirebaseAuth.instance.currentUser!.uid)
          .snapshots()
          .map((QuerySnapshot snapshot) {
        print(snapshot.size.toString() + "asdasdq22");
        events.clear();
        for (int i = 0; i < snapshot.size; i++) {
          Timestamp t = snapshot.docs[i]['eventDate'];
          DateTime d = t.toDate();
          print(d);
          setState(() {
            events.add(d);
          });

          // print(snapshot.docs[i]['createdAt'].toString()+i.toString() + "asdsadda");
        }
      }).single;
    });
  }

  @override
  void dispose() {
    _selectedEvents.dispose();
    super.dispose();
  }

  List<Event> _getEventsForDay(DateTime day) {
    // Implementation example
    return kEvents[day] ?? [];
  }

  List<Event> _getEventsForRange(DateTime start, DateTime end) {
    // Implementation example
    final days = daysInRange(start, end);

    return [
      for (final d in days) ..._getEventsForDay(d),
    ];
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    if (!isSameDay(_selectedDay, selectedDay)) {
      setState(() {
        _selectedDay = selectedDay;
        _focusedDay = focusedDay;
        _rangeStart = null; // Important to clean those
        _rangeEnd = null;
        _rangeSelectionMode = RangeSelectionMode.toggledOff;
      });

      _selectedEvents.value = _getEventsForDay(selectedDay);
    }
    print(_selectedDay);
    print(DateTime.now());

    print(_focusedDay);
  }

  String? viewType = "Month View";
  List<String> viewTypeList = ['Month View', 'Week View', 'Day View'];
  void changeCalendarView() {
    if (viewType == 'Month View') {
      setState(() {
        _calendarFormat = CalendarFormat.month;
      });
    } else if (viewType == 'Week View') {
      setState(() {
        _calendarFormat = CalendarFormat.week;
      });
    } else {
      setState(() {
        _calendarFormat = CalendarFormat.twoWeeks;
      });
    }
  }

  DateTime kToday = DateTime.now();
  DateTime kFirstDay = DateTime(
      DateTime.now().year, DateTime.now().month - 3, DateTime.now().day);
  DateTime kLastDay = DateTime(
      DateTime.now().year, DateTime.now().month + 3, DateTime.now().day);
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('userDetails')
            .where("userId", isEqualTo: FirebaseAuth.instance.currentUser!.uid)
            .limit(1)
            .snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          // String data = snapshot.data.toString();
          if (!snapshot.hasData) return SizedBox();
          return DefaultTabController(
              length: 2,
              child: Scaffold(
                floatingActionButton: FloatingActionButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AddEventScreen()));
                  },
                  child: const Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                ),
                floatingActionButtonLocation:
                    FloatingActionButtonLocation.centerFloat,
                drawer: !snapshot.hasData
                    ? SizedBox()
                    : Drawer(
                        backgroundColor: kCyan,
                        child: ListView(
                          padding: EdgeInsets.zero,
                          children: <Widget>[
                            DrawerHeader(
                                decoration: BoxDecoration(
                                  color: kCyan,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    // SizedBox(height: 5,),
                                    Text(
                                      "Welcome! " +
                                          snapshot.data?.docs[0]['name'],
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                    //   SizedBox(height: 5,),
                                  ],
                                )),
                            ListTile(
                              leading: Icon(
                                Icons.edit,
                                color: Colors.white,
                                size: 25,
                              ),
                              title: Text('Edit Profile',
                                  style: TextStyle(color: Colors.white)),
                              onTap: () async {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => EditProfilePage(
                                            profileDetails:
                                                snapshot.data?.docs[0])));
                              },
                            ),
                            ListTile(
                              leading: Icon(
                                Icons.logout,
                                color: Colors.white,
                                size: 25,
                              ),
                              title: Text('Logout',
                                  style: TextStyle(color: Colors.white)),
                              onTap: () async {
                                final GoogleSignIn _googleSignIn =
                                    GoogleSignIn();
                                await FirebaseAuth.instance.signOut();
                                await _googleSignIn.signOut();
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => RootScreen()));

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("Logged Out"),
                                  ),
                                );
                              },
                            )
                          ],
                        ),
                      ),
                appBar: PreferredSize(
                  preferredSize: Size.fromHeight(130), // Set this height
                  child: Container(
                    //margin: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        AppBar(
                          title: Text("PREM"),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        //   Divider(color: Colors.black,thickness: 2,),
                        TabBar(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          indicator: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(10), // Creates border
                              color: kCyan),

//indicatorColor: Colors.black,
                          tabs: [
                            Tab(
                              child: Text(
                                "Calendar",
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                            Tab(
                                child: Text(
                              "Events",
                              style: TextStyle(color: Colors.black),
                            )),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                backgroundColor: Colors.white,
                body: TabBarView(
                  children: [
                    // tab one view
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                            width: Get.width,
                            height: 50,
                            margin: EdgeInsets.symmetric(
                              horizontal: 20,
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            decoration: BoxDecoration(
                              color: kLightGrey,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(8.0)),
                              border: Border.all(
                                color: kDark,
                                width: 1,
                              ),
                            ),
                            child: DropdownButton2(
                              underline: SizedBox(),
                              isExpanded: true,
                              hint: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Select View Type',
                                    style: kBodyText.copyWith(color: kBlack),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                              items: viewTypeList
                                  .map((item) => DropdownMenuItem<String>(
                                        value: item,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              item,
                                              style: kBodyText.copyWith(
                                                  color: kBlack),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ))
                                  .toList(),
                              value: viewType,
                              onChanged: (value) {
                                setState(() {
                                  if (viewType != value) {
                                    viewType = viewType = value as String;
                                    changeCalendarView();
                                  }
                                });
                              },
                              icon: const Icon(
                                Icons.arrow_drop_down_outlined,
                              ),
                              iconSize: 20,
                              iconEnabledColor: Colors.black45,
                              iconDisabledColor: Colors.grey,
                              buttonPadding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              buttonElevation: 2,
                              itemHeight: 40,
                              itemPadding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              dropdownMaxHeight: 200,
                              dropdownWidth: 200,
                              dropdownPadding: null,
                              dropdownDecoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: new BorderRadius.circular(15.0),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Color.fromRGBO(243, 243, 245, 1),
                                        blurRadius: 4.0,
                                        spreadRadius: 0.4)
                                  ]),
                              dropdownElevation: 8,
                              scrollbarRadius: const Radius.circular(40),
                              scrollbarThickness: 6,
                              scrollbarAlwaysShow: true,
                              offset: const Offset(-20, 0),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: Center(
                              child: viewType == "Day View"
                                  ? Container(
                                      width: Get.width,
                                      padding: EdgeInsets.only(
                                          left: Get.width * 0.20),
                                      child: Row(
                                        children: [
                                          IconButton(
                                              onPressed: () {
                                                setState(() {
                                                  _focusedDay =
                                                      _focusedDay.subtract(
                                                          Duration(days: 1));
                                                });
                                              },
                                              icon: Icon(Icons.arrow_back_ios)),
                                          Text(DateFormat.yMMMEd()
                                              .format(_focusedDay)),
                                          IconButton(
                                              onPressed: () {
                                                setState(() {
                                                  _focusedDay = _focusedDay
                                                      .add(Duration(days: 1));
                                                });
                                              },
                                              icon: Icon(
                                                  Icons.arrow_forward_ios)),
                                        ],
                                      ),
                                    )
                                  : Container(
                                      width: Get.width * 0.90,
                                      // height: 350,
                                      color: kCyan,
                                      child: TableCalendar(
                                        calendarFormat: _calendarFormat,
                                        firstDay: kFirstDay,
                                        lastDay: kLastDay,

                                        focusedDay: _focusedDay,

                                        holidayPredicate: (day) {
                                          //start of has code
                                          var holiday = false;

                                          //end of has code

                                          events.forEach((element) {
                                            if (isSameDay(element, day)) {
                                              holiday = true;
                                            }
                                          });
                                          return holiday == true ? true : false;
                                        },

                                        selectedDayPredicate: (day) =>
                                            isSameDay(_selectedDay, day),
                                        rangeStartDay: _rangeStart,
                                        rangeEndDay: _rangeEnd,

                                        rangeSelectionMode: _rangeSelectionMode,
                                        //   eventLoader: events,
                                        startingDayOfWeek:
                                            StartingDayOfWeek.monday,
                                        daysOfWeekStyle: DaysOfWeekStyle(
                                            weekdayStyle: TextStyle(
                                              color: kBlack,
                                            ),
                                            weekendStyle: TextStyle(
                                              color: kBlack,
                                            ),
                                            decoration: BoxDecoration(
                                              color:
                                                  Colors.white.withOpacity(0.2),
                                            )),
                                        headerStyle: HeaderStyle(
                                          titleCentered: true,
                                          titleTextStyle: TextStyle(
                                            color: Colors.white,
                                          ),
                                          formatButtonVisible: false,
                                          //formatButtonDecoration: BoxDecoration(),
                                          // formatButtonTextStyle: TextStyle(color: kBlack),
                                          leftChevronIcon: Icon(
                                            Icons.arrow_back_ios,
                                            color: Colors.white,
                                          ),
                                          // leftChevronMargin: EdgeInsets.only(left: 100.w),
                                          rightChevronIcon: Icon(
                                            Icons.arrow_forward_ios,
                                            color: Colors.white,
                                          ),
                                        ),

                                        calendarStyle: CalendarStyle(
                                          canMarkersOverflow: true,
                                          tableBorder: TableBorder(
                                            horizontalInside:
                                                BorderSide(color: Colors.grey),
                                            verticalInside:
                                                BorderSide(color: Colors.grey),
                                            bottom:
                                                BorderSide(color: Colors.grey),
                                            left:
                                                BorderSide(color: Colors.grey),
                                            right:
                                                BorderSide(color: Colors.grey),
                                            top: BorderSide(color: Colors.grey),
                                          ),
                                          markerDecoration: BoxDecoration(
                                            color: kDarkGrey,
                                            shape: BoxShape.circle,
                                          ),
                                          outsideTextStyle: TextStyle(
                                            color: Colors.white,
                                          ),
                                          defaultTextStyle: TextStyle(
                                            color: Colors.white,
                                          ),
                                          weekendTextStyle: TextStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                        onDaySelected: _onDaySelected,

                                        onFormatChanged: (format) {
                                          if (_calendarFormat != format) {
                                            setState(() {
                                              _calendarFormat = format;
                                            });
                                          }
                                        },

                                        onPageChanged: (focusedDay) {
                                          setState(() {
                                            _focusedDay = focusedDay;
                                            print(_focusedDay);
                                          });
                                        },
                                      ),
                                    ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection('events')
                                  .where("participantList",
                                      arrayContains: FirebaseAuth
                                          .instance.currentUser!.uid)

                                  // .where("timestamp",isEqualTo: DateTime.now())

                                  // .where("eventDate",isLessThanOrEqualTo: DateTime.now())
                                  .orderBy('eventDate', descending: false)
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                // String data = snapshot.data.toString();
                                if (!snapshot.hasData) return SizedBox();
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children:
                                      snapshot.data!.docs.map((eventDetails) {
                                    //  List<String> imageUrls =List.from(userDocument['picUrl']);

                                    return isDateSame(
                                            eventDetails["eventDate"].toDate())
                                        ? Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                              border: Border.all(
                                                color: kDark,
                                                width: 1,
                                              ),
                                              color: kWhite,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: kCyan,
                                                  spreadRadius: 1,
                                                  blurRadius: 1,
                                                  // offset: Offset(0, 0), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            margin: EdgeInsets.only(
                                                left: 30,
                                                top: MediaQuery.of(context)
                                                        .viewPadding
                                                        .top +
                                                    17,
                                                right: 30),
                                            //  padding: EdgeInsets.only(left: 10,top: 10),
                                            // color: Colors.white,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Name",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                      eventDetails['eventName']
                                                          .toString()
                                                          .capitalizeFirst!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Place",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                        eventDetails[
                                                                'eventPlace']
                                                            .toString()
                                                            .capitalizeFirst!,
                                                        style: kTextNormalStyle(
                                                            14, kDarkGrey)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Price",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                        "€ " +
                                                            eventDetails[
                                                                    'eventPrice']
                                                                .toString()
                                                                .capitalizeFirst!,
                                                        style: kTextNormalStyle(
                                                            14, kDarkGrey)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Event Date",
                                                            style:
                                                                kTextHeadingStyle(
                                                                    17,
                                                                    kBlack)),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                            DateFormat.yMMMEd()
                                                                .format(eventDetails[
                                                                        'eventDate']
                                                                    .toDate())
                                                                .toString()!,
                                                            style:
                                                                kTextNormalStyle(
                                                                    14,
                                                                    kDarkGrey)),
                                                      ],
                                                    ),
                                                    Spacer(),
                                                    Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Event Time",
                                                            style:
                                                                kTextHeadingStyle(
                                                                    17,
                                                                    kBlack)),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                            eventDetails[
                                                                        'eventType'] ==
                                                                    "personal"
                                                                ? DateFormat(
                                                                        'HH:mm')
                                                                    .format(eventDetails[
                                                                            'eventDate']
                                                                        .toDate())
                                                                    .toString()
                                                                    .capitalizeFirst!
                                                                : eventDetails[
                                                                        'eventTime']
                                                                    .toString()
                                                                    .capitalizeFirst!,
                                                            style:
                                                                kTextNormalStyle(
                                                                    14,
                                                                    kDarkGrey)),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      width: 25,
                                                    )
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 25,
                                                )
                                              ],
                                            ),
                                          )
                                        : SizedBox();
                                  }).toList(),
                                );
                              }),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Center(
                            child: CustomButton(
                                color: kCyan,
                                title: "Add New Lecture",
                                onTap: () {
                                  Get.to(() => AddLectureScreen());
                                }),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Center(
                            child: CustomButton(
                                color: kCyan,
                                title: "Edit/View Lecture",
                                onTap: () {
                                  Get.to(() => ViewLectures());
                                }),
                          ),
                          SizedBox(
                            height: 70,
                          )
                        ],
                      ),
                    ),

                    //tab 2 view

                    SingleChildScrollView(
                      child: Column(
                        children: [
                          StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection('events')
                                  .where('eventrId',
                                      isNotEqualTo: FirebaseAuth
                                          .instance.currentUser!.uid)
                                  .where('eventType', isEqualTo: "public")
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                // String data = snapshot.data.toString();
                                if (!snapshot.hasData) return SizedBox();
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children:
                                      snapshot.data!.docs.map((eventDetails) {
                                    List<String> participant = List.from(
                                        eventDetails['participantList']);
                                    List<String> reportList =
                                        List.from(eventDetails['reportList']);

                                    return participant.contains(FirebaseAuth
                                                .instance.currentUser!.uid) ||
                                            reportList.contains(FirebaseAuth
                                                .instance.currentUser!.uid)
                                        ? SizedBox()
                                        : Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                              border: Border.all(
                                                color: kDark,
                                                width: 1,
                                              ),
                                              color: kWhite,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: kCyan,
                                                  spreadRadius: 1,
                                                  blurRadius: 1,
                                                  // offset: Offset(0, 0), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            margin: EdgeInsets.only(
                                                left: 30,
                                                top: MediaQuery.of(context)
                                                        .viewPadding
                                                        .top +
                                                    17,
                                                right: 30),
                                            //  padding: EdgeInsets.only(left: 10,top: 10),
                                            // color: Colors.white,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Name",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                    Spacer(),
                                                    InkWell(
                                                      onTap: () async {
                                                        reportList.add(
                                                            FirebaseAuth
                                                                .instance
                                                                .currentUser!
                                                                .uid);
                                                        await FirebaseFirestore
                                                            .instance
                                                            .collection(
                                                                'events')
                                                            .doc(
                                                                eventDetails.id)
                                                            .update({
                                                          'reportList':
                                                              reportList,
                                                        }).catchError((e) {
                                                          print(e);
                                                        }).whenComplete(
                                                                () async => {
                                                                      updateEventList(),
                                                                      await ScaffoldMessenger.of(
                                                                              context)
                                                                          .showSnackBar(
                                                                        SnackBar(
                                                                          backgroundColor:
                                                                              kCyan,
                                                                          content:
                                                                              Text("Thank you for resporting this event \nWe apologize for your bad experience."),
                                                                        ),
                                                                      ),
                                                                    });
                                                      },
                                                      child: Text("Report",
                                                          style:
                                                              kTextHeadingStyle(
                                                                  15, kRed)),
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    )
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                      eventDetails['eventName']
                                                          .toString()
                                                          .capitalizeFirst!,
                                                      style: kTextNormalStyle(
                                                          14, kDarkGrey),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Place",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                        eventDetails[
                                                                'eventPlace']
                                                            .toString()
                                                            .capitalizeFirst!,
                                                        style: kTextNormalStyle(
                                                            14, kDarkGrey)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text("Event Price",
                                                        style:
                                                            kTextHeadingStyle(
                                                                17, kBlack)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Text(
                                                        "€ " +
                                                            eventDetails[
                                                                    'eventPrice']
                                                                .toString()
                                                                .capitalizeFirst!,
                                                        style: kTextNormalStyle(
                                                            14, kDarkGrey)),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Event Date",
                                                            style:
                                                                kTextHeadingStyle(
                                                                    17,
                                                                    kBlack)),
                                                        SizedBox(
                                                          width: 5,
                                                        ),
                                                        Text(
                                                            DateFormat.yMMMEd()
                                                                .format(eventDetails[
                                                                        'eventDate']
                                                                    .toDate())
                                                                .toString()!,
                                                            style:
                                                                kTextNormalStyle(
                                                                    14,
                                                                    kDarkGrey)),
                                                      ],
                                                    ),
                                                    Spacer(),
                                                    Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Event Time",
                                                            style:
                                                                kTextHeadingStyle(
                                                                    17,
                                                                    kBlack)),
                                                        SizedBox(
                                                          width: 5,
                                                        ),
                                                        Text(
                                                            eventDetails[
                                                                    'eventTime']
                                                                .toString()
                                                                .capitalizeFirst!,
                                                            style:
                                                                kTextNormalStyle(
                                                                    14,
                                                                    kDarkGrey)),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      width: 15,
                                                    )
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Center(
                                                  child: CustomButton(
                                                      color: kCyan,
                                                      title: "Buy Your Ticket",
                                                      onTap: () async {
                                                        participant.add(
                                                            FirebaseAuth
                                                                .instance
                                                                .currentUser!
                                                                .uid);
                                                        await FirebaseFirestore
                                                            .instance
                                                            .collection(
                                                                'events')
                                                            .doc(
                                                                eventDetails.id)
                                                            .update({
                                                          'participantList':
                                                              participant,
                                                        }).catchError((e) {
                                                          print(e);
                                                        }).whenComplete(
                                                                () async => {
                                                                      updateEventList(),
                                                                      await ScaffoldMessenger.of(
                                                                              context)
                                                                          .showSnackBar(
                                                                        SnackBar(
                                                                          backgroundColor:
                                                                              kCyan,
                                                                          content:
                                                                              Text("Event Purchased"),
                                                                        ),
                                                                      ),
                                                                    });
                                                      }),
                                                ),
                                                SizedBox(
                                                  height: 15,
                                                )
                                              ],
                                            ),
                                          );
                                    //if search is less then 3 characters
                                  }).toList(),
                                );
                              }),
                          SizedBox(
                            height: 10,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ));
        });
  }
}
