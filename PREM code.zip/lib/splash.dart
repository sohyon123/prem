import 'dart:async';
import 'dart:core';

import 'package:evenmanagment/constants/constants.dart';
import 'package:evenmanagment/root.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

//This class will show the logo for 3 seconds before the root bage
class SplashPage extends StatefulWidget {
  const SplashPage({super.key, required});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  startTime() async {
    var _duration = new Duration(seconds: 5);
    return new Timer(_duration, navigationPage);
  }

  Future<void> navigationPage() async {
    //how the next page will show (page transition)
    Navigator.push(
        context,
        PageTransition(
            curve: Curves.bounceOut,
            type: PageTransitionType.rotate,
            alignment: Alignment.topCenter,
            duration: Duration(milliseconds: 1000),
            child: RootScreen()));
  }

  @override
  void initState() {
    super.initState();

    startTime();
  }

//how the splash page will look like (should take logo from assets folder)
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhite,
      body: Center(
        child: new Image.asset(
          'assets/logo.jpg',
          fit: BoxFit.cover,
          height: 200,
          width: 250,
          alignment: Alignment.center,
        ),
      ),

      //  trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
